# FalixNodes-Old-Pterodactyl-APi-Discord-panel-website
This website was created for website to connect to pterodactyl api with discord login.

It's is kinda broken tho as it can be xss & mysql injected

It is able block vpns & proxy(some countrys have problems cause of there internet)

Saves data in mysql

Paypal 
Auto Renew Plans
1 time plans

Created by Mario 

Used on limitednodes and FalixNodes

Website works but has a lot of bugs you can use this however you want. 

:D

Wonder where i got this and why i uploaded?

I got this as i work for limitednodes & the owner was friend with the web developer of falixnodes (Mario)
Well he got there source code and everything and that how it came be for limitednodes but Summerhoax told us about the xss problem & mysql injected. so we closed the host. 

The new falixnodes based on this code but bit more fix as i know still able be xss or mysql injected from last time i saw it.

This website only for those who know how fix or do what you want with best not start a host with it for free hosting as it broken unless you can fix it for your self.
