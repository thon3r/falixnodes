<html>
	<head>
		<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.0.min.js"></script>
		<script>function load_res(o){$("#app").load(o)}$(document).ready(function(){load_res("another")});</script>
	</head>
	
	<body>
		<div id="app"></div>
	</body>
</html>