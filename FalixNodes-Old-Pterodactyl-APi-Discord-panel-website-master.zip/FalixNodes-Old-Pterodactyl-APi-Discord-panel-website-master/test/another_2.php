Let's make it deeper! Click again.
<br />
<a href="#/index" onclick='alert("Go away from where you came! There is nothing to show !! hehe.");'>Reveal secret now?</a>