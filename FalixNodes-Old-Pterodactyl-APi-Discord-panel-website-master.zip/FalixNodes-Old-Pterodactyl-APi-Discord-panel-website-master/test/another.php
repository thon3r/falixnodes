Hi! You got a secret here... actually, this secret is just awesome!
<br />
<a href="#/another_2" onclick='load_res("another_2")'>Reveal the secret!</a>